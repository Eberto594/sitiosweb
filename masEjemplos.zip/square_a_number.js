var square_a_number = function(num) {
	var value = num * num;
	return value;
};

alert("The square of 3 is " + square_a_number(3));
alert("The square of 4 is " + square_a_number(4));
