var my_age;
var my_name;

my_name = prompt("What is your name?");
my_age = parseInt(prompt("What is your age?"));

if(my_age == 18 && my_name == "Fred") {
	alert("Your name is Fred and you are 18!");
}

