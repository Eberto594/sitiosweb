var answer;

while(answer != "Genesis") {
	answer = prompt("What is the first book in the Bible?");
}
alert("You got the answer right!");
