var sum = 0;
for(var num = 1; num <= 6; num = num + 1) {
	sum = sum + num;
}
alert("The sum of the numbers 1 through 6 is " + sum);

