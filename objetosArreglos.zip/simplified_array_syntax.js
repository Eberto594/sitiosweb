// Create an empty array 
var empty_array = [];

// Creates the array we had before 
var children_ages = [11, 8, 7]; 

// Gets the largest value in children_ages
var largest = largest_age(children_ages);

// Skip the variable, pass in the array directly 
var largest_inline = largest_age([11, 8, 7]); 

