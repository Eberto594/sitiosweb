var my_record = {
	name: "Jon",
	children: [
		{
			name: "Jim",
			age: 11,
			favorite_color: "blue"
		},
		{
			name: "Jack",
			age: 8,
			favorite_color: "black"
		},
		{
			name: "Joel",
			age: 7,
			favorite_color: "orange"
		}
	]
};
