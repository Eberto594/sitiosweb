var children_ages = new Array();
children_ages[0] = 11;
children_ages[1] = 8;
children_ages[2] = 7;

var largest = largest_age(children_ages);
alert("The oldest child is " + largest + " years old");
